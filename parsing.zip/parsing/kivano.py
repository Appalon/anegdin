import requests

import telebot
import random
from bs4 import BeautifulSoup as b

URL = 'https://www.anekdot.ru/last/good/' #1 APi cайта 
API_KEY = '6026509519:AAGJ4TQcYwtDWAyf-gZ-PN2FMzN5IPYcSbs'  #2  токен бота

def parser(url): #выкачываем форму
    r = requests.get(url)  #3 НАЧАЛА ПРОВЕРКИ
# print(r.status_code) # 3/1 проверка кода (200)
# print(r.text) # 3/2 выводить мне весь код из дивок
    soup = b(r.text, 'html.parser') # 4 проверка без бота 
    anekdots =  soup.find_all('div', class_= 'text')  # 5 тут мы ищем именно теги которые хатим обращатся
    return [c.text for c in anekdots]
# clear_anekdots = [c.text for c in anekdots] #вывод без тег и лишних слов 5/1
# print(clear_anekdots) #естественно проверка 5/2

list_of_jkes = parser(URL)   #список с анигдотами * что это будет! мы вызовим фукцию парсер 

random.shuffle(list_of_jkes) # перемещенный список анигдотов

bot = telebot.TeleBot(API_KEY)

@bot.message_handler(commands=['start'])
def start(message):

    first_name = message.from_user.first_name
    bot.send_message(message.chat.id, f"Здравствуйте <b>{first_name}!</b> отправьте любую цифру для получения анегдотов", parse_mode='html')

    stic = open('/home/baiel/bots/weather_bot/memy/sticker.webp', mode='rb')
    bot.send_sticker(message.chat.id, stic )

@bot.message_handler(content_types=['text'])
def jokes(message): #начинаем фунцую про щутки
    if message.text.lower()in '12345678901234':  # lower чтобы цивры были строчними
        bot.send_message(message.chat.id,list_of_jkes[0])  # отправляем онигдотик
        del list_of_jkes[0]  # этот команда удаляет анигдоты которые уже нам отправил бот и не дает возможность повтярять

    else:
        bot.send_message(message.chat.id,'бекзот ака бля номур жазын')  # для тот сличя когда польз отправляет буквы



bot.polling(non_stop=True)
                